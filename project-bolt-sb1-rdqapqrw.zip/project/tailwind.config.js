/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#ff4500',
        secondary: '#0d0d0d',
        neutral: {
          white: '#ffffff',
          light: '#f5f5f5',
          gray: '#6b7280',
          dark: '#374151'
        }
      },
      fontFamily: {
        'heading': ['Poppins', 'sans-serif'],
        'body': ['Inter', 'sans-serif']
      },
      spacing: {
        'section-desktop': '80px',
        'section-mobile': '40px',
        'gutter': '24px'
      },
      maxWidth: {
        'container': '1200px'
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-orange-red': 'linear-gradient(135deg, #ff4500 0%, #dc2626 100%)',
        'gradient-orange': 'linear-gradient(135deg, #ff4500 0%, #ea580c 100%)'
      },
      boxShadow: {
        'soft': '0 20px 40px rgba(0, 0, 0, 0.3)',
        'glow-orange': '0 0 30px rgba(255, 69, 0, 0.4)',
        'glow-orange-lg': '0 0 50px rgba(255, 69, 0, 0.6)'
      },
      animation: {
        'fade-in': 'fadeIn 0.6s cubic-bezier(0.4, 0, 0.2, 1) forwards',
        'fade-in-delay': 'fadeIn 0.6s cubic-bezier(0.4, 0, 0.2, 1) 0.3s forwards',
        'fade-in-delay-2': 'fadeIn 0.6s cubic-bezier(0.4, 0, 0.2, 1) 0.6s forwards',
        'pulse-orange': 'pulseOrange 2s cubic-bezier(0.4, 0, 0.2, 1) infinite'
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' }
        },
        pulseOrange: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(255, 69, 0, 0.7)' },
          '70%': { boxShadow: '0 0 0 10px rgba(255, 69, 0, 0)' }
        }
      },
      lineHeight: {
        'heading': '1.2',
        'body': '1.5'
      },
      letterSpacing: {
        'heading': '0.025em'
      }
    },
  },
  plugins: [],
};