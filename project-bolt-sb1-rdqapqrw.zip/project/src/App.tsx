import React from 'react';
import Navigation from './components/Navigation';
import HeroSection from './components/HeroSection';
import FeaturesSection from './components/FeaturesSection';
import TestimonialSection from './components/TestimonialSection';
import CTASection from './components/CTASection';
import StatsSection from './components/StatsSection';
import PlaceholderSections from './components/PlaceholderSections';
import Footer from './components/Footer';
import InteractiveTeaserSection from './components/InteractiveTeaserSection';

function App() {
  return (
    <div className="relative">
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <TestimonialSection />
      <CTASection />
      <StatsSection />
      <PlaceholderSections />
      <InteractiveTeaserSection />
      <Footer />
    </div>
  );
}

export default App;