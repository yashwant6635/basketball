import React from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  Video, 
  Trophy, 
  Users, 
  Zap, 
  Smartphone 
} from 'lucide-react';

const FeaturesSection = () => {
  const features = [
    {
      icon: BarChart3,
      title: "AI Performance Analytics",
      description: "Advanced AI algorithms analyze your shooting form, movement patterns, and game statistics for personalized insights."
    },
    {
      icon: Video,
      title: "Video Breakdown & Highlights",
      description: "Automatically generate highlight reels and detailed breakdowns of your best plays and areas for improvement."
    },
    {
      icon: Trophy,
      title: "Personalized Training Programs",
      description: "Custom training routines tailored to your skill level, position, and specific goals for maximum improvement."
    },
    {
      icon: Users,
      title: "Community Challenges",
      description: "Compete with players worldwide in skill challenges and track your progress on global leaderboards."
    },
    {
      icon: Zap,
      title: "Real-time Feedback",
      description: "Instant coaching feedback during practice sessions using computer vision and motion tracking technology."
    },
    {
      icon: Smartphone,
      title: "Mobile Friendly Experience",
      description: "Access all features seamlessly across devices with our responsive design and native mobile app integration."
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.9
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section id="features" className="section bg-gradient-to-b from-secondary to-[#1a1a1a] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, #ff4500 0%, transparent 50%), 
                           radial-gradient(circle at 75% 75%, #ff4500 0%, transparent 50%)`
        }}></div>
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <motion.div 
          className="section-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">
            Why Choose HoopVision?
          </h2>
          <p className="section-subtitle">
            Train smarter, analyze your game, and level up with <span className="text-highlight">AI</span>-driven basketball insights.
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div 
          className="grid-responsive"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <motion.div
                key={index}
                variants={cardVariants}
                whileHover={{ 
                  y: -8,
                  scale: 1.02,
                  transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] }
                }}
                className="group relative"
              >
                <div className="card card-hover h-full">
                  {/* Glow Effect */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-primary/0 via-primary/0 to-primary/0 group-hover:from-primary/5 group-hover:via-primary/10 group-hover:to-primary/5 transition-smooth"></div>
                  
                  {/* Content */}
                  <div className="relative z-10">
                    {/* Icon */}
                    <div className="mb-6">
                      <div className="icon-container">
                        <IconComponent className="icon-large text-white" />
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="heading-tertiary mb-4 group-hover:text-primary transition-smooth">
                      {feature.title}
                    </h3>

                    {/* Description */}
                    <p className="body-small">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4, ease: [0.4, 0, 0.2, 1] }}
          viewport={{ once: true }}
        >
          <button className="group btn-primary">
            <span className="flex items-center justify-center gap-2">
              Start Your Journey
              <motion.div
                animate={{ x: [0, 4, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: [0.4, 0, 0.2, 1] }}
              >
                →
              </motion.div>
            </span>
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesSection;