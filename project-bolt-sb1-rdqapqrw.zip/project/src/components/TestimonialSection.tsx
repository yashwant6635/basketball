import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const TestimonialSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const testimonials = [
    {
      id: 1,
      name: "Jordan M.",
      role: "High School Player",
      avatar: "https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop&crop=face",
      rating: 5,
      text: "HoopVision completely changed how I approach training. The AI analytics helped me improve my shooting percentage by 30% in just two months. The personalized feedback is incredible!"
    },
    {
      id: 2,
      name: "Sarah K.",
      role: "College Basketball Coach",
      avatar: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop&crop=face",
      rating: 5,
      text: "As a coach, HoopVision gives me insights I never had before. The video breakdown feature helps my players understand their mistakes and improve faster than traditional methods."
    },
    {
      id: 3,
      name: "Marcus T.",
      role: "Professional Player",
      avatar: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop&crop=face",
      rating: 5,
      text: "The real-time feedback during practice sessions is game-changing. HoopVision's technology helped me refine my technique and take my game to the professional level."
    },
    {
      id: 4,
      name: "Alex R.",
      role: "Youth League Player",
      avatar: "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop&crop=face",
      rating: 4,
      text: "I love the community challenges! Competing with players worldwide keeps me motivated. The mobile app makes it easy to track my progress anywhere I go."
    },
    {
      id: 5,
      name: "Coach Williams",
      role: "AAU Coach",
      avatar: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop&crop=face",
      rating: 5,
      text: "HoopVision's training programs are perfectly tailored to each player's needs. I've seen remarkable improvement in my team's performance since we started using the platform."
    }
  ];

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, testimonials.length]);

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-5 h-5 ${
          index < rating ? 'text-orange-500 fill-orange-500' : 'text-gray-400'
        }`}
      />
    ));
  };

  return (
    <section 
      className="section bg-gradient-to-b from-[#1a1a1a] to-[#262626] relative overflow-hidden"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 20% 80%, #ff4500 0%, transparent 50%), 
                           radial-gradient(circle at 80% 20%, #ff4500 0%, transparent 50%)`
        }}></div>
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <motion.div 
          className="section-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">
            Trusted by Athletes Everywhere
          </h2>
          <p className="section-subtitle">
            Players and coaches are transforming their game with HoopVision.
          </p>
        </motion.div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-6xl mx-auto">
          {/* Desktop Navigation Arrows */}
          <div className="hidden md:block">
            <button
              onClick={prevTestimonial}
              className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-12 z-10 w-12 h-12 bg-gray-800/80 hover:bg-gray-700 rounded-full flex items-center justify-center transition-smooth hover:scale-110 shadow-soft"
            >
              <ChevronLeft className="icon-white" />
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-12 z-10 w-12 h-12 bg-gray-800/80 hover:bg-gray-700 rounded-full flex items-center justify-center transition-smooth hover:scale-110 shadow-soft"
            >
              <ChevronRight className="icon-white" />
            </button>
          </div>

          {/* Carousel Container */}
          <div className="overflow-hidden rounded-2xl">
            <motion.div 
              className="flex transition-transform duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                  <motion.div
                    className="bg-secondary p-8 sm:p-10 rounded-2xl shadow-soft border border-gray-800/50 hover:border-primary/30 transition-smooth max-w-4xl mx-auto"
                    whileHover={{ 
                      scale: 1.02,
                      y: -5,
                      transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] }
                    }}
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1, ease: [0.4, 0, 0.2, 1] }}
                    viewport={{ once: true }}
                  >
                    {/* Testimonial Content */}
                    <div className="text-center">
                      {/* Avatar */}
                      <div className="mb-6">
                        <img
                          src={testimonial.avatar}
                          alt={testimonial.name}
                          className="w-20 h-20 rounded-full mx-auto object-cover border-4 border-primary/20 shadow-soft"
                        />
                      </div>

                      {/* Rating */}
                      <div className="flex justify-center mb-6">
                        {renderStars(testimonial.rating)}
                      </div>

                      {/* Testimonial Text */}
                      <blockquote className="body-large mb-8 italic">
                        "{testimonial.text}"
                      </blockquote>

                      {/* Name and Role */}
                      <div>
                        <h4 className="heading-tertiary mb-1">
                          {testimonial.name}
                        </h4>
                        <p className="text-primary font-medium font-body">
                          {testimonial.role}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-smooth ${
                  index === currentIndex 
                    ? 'bg-primary scale-125' 
                    : 'bg-gray-600 hover:bg-gray-500'
                }`}
              />
            ))}
          </div>

          {/* Mobile Swipe Indicators */}
          <div className="md:hidden flex justify-center mt-6 space-x-4">
            <button
              onClick={prevTestimonial}
              className="w-10 h-10 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-smooth"
            >
              <ChevronLeft className="icon-primary text-white" />
            </button>
            <button
              onClick={nextTestimonial}
              className="w-10 h-10 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-smooth"
            >
              <ChevronRight className="icon-primary text-white" />
            </button>
          </div>
        </div>

        {/* Bottom CTA */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4, ease: [0.4, 0, 0.2, 1] }}
          viewport={{ once: true }}
        >
          <button className="group btn-primary">
            <span className="flex items-center justify-center gap-2">
              Join Thousands of Athletes
              <motion.div
                animate={{ x: [0, 4, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: [0.4, 0, 0.2, 1] }}
              >
                →
              </motion.div>
            </span>
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialSection;