import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Play } from 'lucide-react';

const CTASection: React.FC = () => {
  return (
    <section className="relative py-20 bg-gradient-to-br from-secondary to-gray-900 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/20 to-transparent transform -skew-y-12"></div>
      </div>
      
      {/* Floating Basketball Icons */}
      <div className="absolute top-20 left-10 w-16 h-16 bg-primary/10 rounded-full blur-sm animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-24 h-24 bg-primary/5 rounded-full blur-md animate-pulse delay-1000"></div>
      <div className="absolute top-1/2 left-1/4 w-8 h-8 bg-primary/20 rounded-full blur-sm animate-pulse delay-500"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-4xl mx-auto"
        >
          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white via-primary to-red-500 bg-clip-text text-transparent leading-tight"
          >
            Take Your Game to the{' '}
            <span className="text-primary">Next Level</span>
          </motion.h2>
          
          {/* Subtext */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed"
          >
            Join HoopVision today and unlock personalized{' '}
            <span className="text-primary font-semibold">AI-powered training</span>{' '}
            that adapts to your unique playing style.
          </motion.p>
          
          {/* Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12"
          >
            {/* Primary Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group relative px-8 py-4 bg-gradient-to-r from-primary to-red-500 text-white font-semibold rounded-xl text-lg shadow-lg hover:shadow-primary/25 transition-all duration-300 flex items-center gap-3"
            >
              <span>Get Started Free</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-red-500 rounded-xl blur opacity-0 group-hover:opacity-50 transition-opacity duration-300 -z-10"></div>
            </motion.button>
            
            {/* Secondary Button */}
            <motion.button
              whileHover={{ scale: 1.05, backgroundColor: 'rgba(255, 69, 0, 0.1)' }}
              whileTap={{ scale: 0.95 }}
              className="group px-8 py-4 border-2 border-white text-white font-semibold rounded-xl text-lg hover:bg-white hover:text-secondary transition-all duration-300 flex items-center gap-3"
            >
              <Play className="w-5 h-5" />
              <span>Watch Demo</span>
            </motion.button>
          </motion.div>
          
          {/* Trust Indicator */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex items-center justify-center gap-4 text-gray-400"
          >
            <div className="flex -space-x-2">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="w-8 h-8 bg-gradient-to-br from-primary to-red-500 rounded-full border-2 border-secondary flex items-center justify-center text-white text-xs font-bold"
                >
                  {i}
                </div>
              ))}
            </div>
            <span className="text-sm">
              Join <span className="text-primary font-semibold">10,000+</span> athletes already training smarter
            </span>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;