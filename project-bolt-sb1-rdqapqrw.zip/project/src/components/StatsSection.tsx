import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

const StatsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const stats = [
    {
      number: 10000,
      suffix: '+',
      label: 'Players Trained Worldwide',
      duration: 2000
    },
    {
      number: 95,
      suffix: '%',
      label: 'Reported Performance Improvement',
      duration: 2200
    },
    {
      number: 500,
      suffix: '+',
      label: 'Coaches Onboarded',
      duration: 1800
    },
    {
      number: 24,
      suffix: '/7',
      label: 'AI-Powered Feedback',
      duration: 1500
    }
  ];

  // Intersection Observer to trigger animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Animated Counter Component
  const AnimatedCounter = ({ 
    number, 
    suffix, 
    duration, 
    delay = 0 
  }: { 
    number: number; 
    suffix: string; 
    duration: number; 
    delay?: number; 
  }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
      if (!isVisible) return;

      const timer = setTimeout(() => {
        let start = 0;
        const end = number;
        const increment = end / (duration / 16);
        
        const counter = setInterval(() => {
          start += increment;
          if (start >= end) {
            setCount(end);
            clearInterval(counter);
          } else {
            setCount(Math.floor(start));
          }
        }, 16);

        return () => clearInterval(counter);
      }, delay);

      return () => clearTimeout(timer);
    }, [isVisible, number, duration, delay]);

    return (
      <span>
        {count.toLocaleString()}{suffix}
      </span>
    );
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const statVariants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.8
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <section 
      ref={sectionRef}
      className="section bg-secondary relative overflow-hidden"
    >
      {/* Carbon Fiber Texture Background */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(45deg, transparent 35%, rgba(255, 255, 255, 0.1) 35%, rgba(255, 255, 255, 0.1) 65%, transparent 65%),
              linear-gradient(-45deg, transparent 35%, rgba(0, 0, 0, 0.1) 35%, rgba(0, 0, 0, 0.1) 65%, transparent 65%)
            `,
            backgroundSize: '20px 20px'
          }}
        ></div>
      </div>

      {/* Subtle Grid Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255, 69, 0, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 69, 0, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        ></div>
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <motion.div 
          className="section-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">
            The HoopVision Impact
          </h2>
          <p className="section-subtitle">
            Real results from athletes and coaches worldwide
          </p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div 
          className="grid-4-col lg:gap-12"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              variants={statVariants}
              whileHover={{ 
                scale: 1.05,
                transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] }
              }}
              className="group text-center"
            >
              <div className="relative">
                {/* Glow Effect Background */}
                <div className="absolute inset-0 bg-primary opacity-0 group-hover:opacity-10 blur-xl transition-smooth rounded-full"></div>
                
                {/* Stat Number */}
                <div className="relative z-10 mb-4">
                  <div className="text-5xl sm:text-6xl lg:text-7xl font-heading font-bold text-primary mb-2 group-hover:text-primary/80 transition-smooth">
                    {isVisible ? (
                      <AnimatedCounter 
                        number={stat.number} 
                        suffix={stat.suffix}
                        duration={stat.duration}
                        delay={index * 200}
                      />
                    ) : (
                      `0${stat.suffix}`
                    )}
                  </div>
                  
                  {/* Accent Underline */}
                  <div className="w-16 h-1 bg-primary mx-auto rounded-full group-hover:w-20 group-hover:bg-primary/80 transition-smooth"></div>
                </div>

                {/* Stat Label */}
                <p className="body-small sm:text-base uppercase tracking-wider font-semibold group-hover:text-gray-300 transition-smooth">
                  {stat.label}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom Accent */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6, ease: [0.4, 0, 0.2, 1] }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center space-x-2 body-small">
            <div className="w-8 h-px bg-gradient-to-r from-transparent to-primary"></div>
            <span className="font-light">Growing every day</span>
            <div className="w-8 h-px bg-gradient-to-l from-transparent to-primary"></div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default StatsSection;