import React from 'react';
import { Target, Users, Trophy, Mail, Play } from 'lucide-react';

const PlaceholderSections = () => {
  return (
    <>
      {/* Training Section */}
      <section id="training" className="section bg-black">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Training Programs</h2>
            <p className="section-subtitle max-w-2xl mx-auto">
              Comprehensive training programs designed for every skill level
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="heading-tertiary mb-6">Personalized Training Plans</h3>
              <ul className="space-y-4 body-regular">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                  Individual skill assessment and customized training programs
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                  Progressive difficulty levels to match your development
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                  Regular performance tracking and feedback sessions
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                  Mental conditioning and game strategy development
                </li>
              </ul>
            </div>
            <div className="card">
              <div className="aspect-video bg-gray-700 rounded-xl relative overflow-hidden">
                <video
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover rounded-xl"
                >
                  <source
                    src="https://res.cloudinary.com/dw2lhwcqe/video/upload/v1755530816/g8n8z7pmlqhnlngbeu7j.mp4"
                    type="video/mp4"
                  />
                  Your browser does not support the video tag.
                </video>
                
                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/10 transition-all duration-300 cursor-pointer group">
                  <div className="w-16 h-16 bg-primary/80 rounded-full flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-smooth">
                    <Play className="w-8 h-8 text-white ml-1" />
                  </div>
                </div>
              </div>
              <p className="body-regular mt-4 text-center">Training Program Overview</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section bg-gray-900">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Get In Touch</h2>
            <p className="section-subtitle max-w-2xl mx-auto">
              Ready to start your basketball journey? Contact us today
            </p>
          </div>
          
          <div className="max-w-2xl mx-auto">
            <div className="card">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="text-center">
                  <Mail className="icon-large text-primary mx-auto mb-2" />
                  <h3 className="text-lg font-semibold text-white mb-1 font-heading">Email</h3>
                  <p className="body-regular">info@hoopvision.com</p>
                </div>
                <div className="text-center">
                  <Target className="icon-large text-primary mx-auto mb-2" />
                  <h3 className="text-lg font-semibold text-white mb-1 font-heading">Location</h3>
                  <p className="body-regular">Training Centers Nationwide</p>
                </div>
              </div>
              
              <div className="text-center">
                <button className="btn-primary">
                  Schedule a Session
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PlaceholderSections;