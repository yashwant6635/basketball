import React, { useState } from 'react';
import { Twitter, Instagram, Youtube, Mail } from 'lucide-react';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const quickLinks = [
    { name: 'Home', id: 'home' },
    { name: 'Features', id: 'features' },
    { name: 'Testimonials', id: 'testimonials' },
    { name: 'Pricing', id: 'pricing' },
    { name: 'Contact', id: 'contact' },
  ];

  const socialLinks = [
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Youtube, href: '#', label: 'YouTube' },
  ];

  return (
    <footer className="bg-[#0a0a0a] text-white">
      {/* Main Footer Content */}
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {/* Branding Section */}
          <div className="space-y-6">
            {/* Logo */}
            <div>
              <h3 className="heading-tertiary mb-2">
                🏀 HoopVision
              </h3>
              <p className="body-small max-w-xs">
                <span className="text-highlight">AI</span>-driven basketball training for the next generation.
              </p>
            </div>

            {/* Social Media Icons */}
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 bg-gray-800 hover:bg-primary rounded-full flex items-center justify-center transition-smooth hover:scale-110 group"
                  >
                    <IconComponent className="icon-primary text-gray-400 group-hover:text-white transition-smooth" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links Section */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-white font-heading">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-gray-400 hover:text-white transition-smooth relative group body-small font-body"
                  >
                    {link.name}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-smooth"></span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter Signup Section */}
          <div className="space-y-6">
           <h4 className="text-lg font-semibold text-white font-heading">Stay Updated</h4>
           <p className="body-small">
              Get the latest training tips and product updates.
            </p>
            
            <form onSubmit={handleSubscribe} className="space-y-4">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-smooth font-body"
                  required
                />
                <Mail className="absolute right-3 top-1/2 transform -translate-y-1/2 icon-primary text-gray-400" />
              </div>
              
              <button
                type="submit"
                disabled={isSubscribed}
                className={`w-full px-6 py-3 rounded-xl font-semibold body-small font-body transition-smooth transform active:scale-95 ${
                  isSubscribed
                    ? 'bg-green-600 text-white cursor-not-allowed'
                    : 'bg-primary hover:bg-primary/90 text-white hover:shadow-soft hover:shadow-glow-orange hover:scale-105'
                }`}
              >
                {isSubscribed ? '✓ Subscribed!' : 'Subscribe'}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#1a1a1a]">
        <div className="container py-6">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
            {/* Copyright */}
            <p className="body-small">
              © 2025 HoopVision. All rights reserved.
            </p>
            
            {/* Additional Links */}
            <div className="flex space-x-6 body-small">
              <a href="#" className="text-gray-400 hover:text-white transition-smooth font-body">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-smooth font-body">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;