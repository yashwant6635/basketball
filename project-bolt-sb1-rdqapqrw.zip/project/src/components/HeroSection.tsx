import React from 'react';
import { Play, ArrowRight } from 'lucide-react';

const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-screen overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source
            src="https://res.cloudinary.com/dw2lhwcqe/video/upload/v1755437545/ryp0plfsdqdxyuxnqq4x.mp4"
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-black/60"></div>
      </div>
      
      {/* Basketball Pattern Overlay */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, #ff4500 0%, transparent 50%), 
                           radial-gradient(circle at 75% 75%, #ff4500 0%, transparent 50%)`
        }}></div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 sm:px-6 lg:px-8 pt-16">
        <div className="text-center container">
          {/* Main Heading */}
          <h1 className="heading-primary mb-6 animate-fade-in">
            Elevate Your
            <span className="block text-highlight">
              Game
            </span>
          </h1>

          {/* Subheading */}
          <p className="body-large mb-12 max-w-3xl mx-auto animate-fade-in-delay">
            Basketball training reimagined.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center animate-fade-in-delay-2">
            {/* Primary Button */}
            <button className="group btn-primary w-full sm:w-auto">
              <span className="flex items-center justify-center gap-2">
                Get Started
                <ArrowRight className="icon-primary group-hover:translate-x-1 transition-smooth" />
              </span>
            </button>

            {/* Secondary Button */}
            <button className="group btn-secondary w-full sm:w-auto">
              <span className="flex items-center justify-center gap-2">
                <Play className="icon-primary group-hover:scale-110 transition-smooth" />
                Learn More
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="animate-bounce">
          <div className="w-6 h-10 border-2 border-white/40 rounded-full relative">
            <div className="w-1 h-3 bg-white/60 rounded-full absolute left-1/2 top-2 transform -translate-x-1/2 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;