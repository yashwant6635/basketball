import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, X, Zap, Target, TrendingUp } from 'lucide-react';

const InteractiveTeaserSection = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const aiResponses = {
    'shoot 3-pointer': "🎯 Great choice! I notice your shooting form has 87% accuracy potential. Try adjusting your elbow alignment 2° inward and increase your follow-through by 0.3 seconds for optimal arc trajectory.",
    'dribble': "⚡ Your ball handling shows promise! I detect slight hesitation in your crossover. Practice the rhythm: bounce-step-bounce with 15% more wrist snap for better control.",
    'layup': "🏀 Nice drive! Your approach angle is solid, but I recommend a 12% softer touch on release. Your success rate could improve from 78% to 91% with this adjustment.",
    'defense': "🛡️ Strong defensive stance! Your reaction time is 0.2s faster than average. Focus on keeping your center of gravity 3 inches lower for even better lateral movement.",
    'jump shot': "📈 Excellent form foundation! Your release point is consistent, but try increasing your leg drive by 18% for more power and range. Your shooting percentage could jump to 85%!",
    'free throw': "🎯 Your free throw routine shows good consistency. I recommend a 2-second longer pause before release and 5% more arc for optimal swish trajectory.",
    'rebound': "💪 Great positioning instincts! Your box-out technique is solid. Try jumping 0.1s earlier and extending your reach 8% more for maximum board control."
  };

  const handleTryDemo = () => {
    setIsModalOpen(true);
    setUserInput('');
    setAiResponse('');
  };

  const handleAnalyzeMove = () => {
    if (!userInput.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis delay
    setTimeout(() => {
      const lowerInput = userInput.toLowerCase();
      let response = "🤖 Interesting move! I'm analyzing your technique and will provide personalized feedback based on biomechanical data and performance metrics.";
      
      // Check for matching responses
      for (const [key, value] of Object.entries(aiResponses)) {
        if (lowerInput.includes(key)) {
          response = value;
          break;
        }
      }
      
      setAiResponse(response);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAnalyzeMove();
    }
  };

  return (
    <>
      <section className="section relative overflow-hidden">
        {/* Spotlight Gradient Background */}
        <div className="absolute inset-0 bg-secondary">
          <div className="absolute inset-0 bg-gradient-radial from-[#1a1a1a] via-secondary to-[#000000] opacity-80"></div>
        </div>

        {/* Subtle Pattern Overlay */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 50% 50%, #ff4500 0%, transparent 70%)`
          }}></div>
        </div>

        <div className="container relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Text Content */}
            <motion.div
              className="text-center lg:text-left flex flex-col justify-center"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
              viewport={{ once: true }}
            >
              <h2 className="heading-secondary mb-6">
                Experience <span className="text-highlight">AI</span> Coaching
                <span className="block text-highlight">
                  Instantly
                </span>
              </h2>
              
              <p className="body-large mb-8">
                Try HoopVision's smart assistant — see how it analyzes your moves.
              </p>

              <div className="flex justify-center lg:justify-start">
                <motion.button
                  onClick={handleTryDemo}
                  className="group btn-primary min-w-[200px]"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="flex items-center justify-center gap-2">
                    <Zap className="icon-primary group-hover:scale-110 transition-smooth" />
                    Try <span className="text-highlight">AI</span> Demo
                  </span>
                  
                  {/* Pulse Animation */}
                  <div className="absolute inset-0 rounded-xl bg-primary opacity-0 group-hover:opacity-20 animate-pulse-orange"></div>
                </motion.button>
              </div>
            </motion.div>

            {/* Right Side - Demo Box */}
            <motion.div
              className="flex justify-center lg:justify-start"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2, ease: [0.4, 0, 0.2, 1] }}
              viewport={{ once: true }}
            >
              <motion.div
                className="relative group cursor-pointer"
                onClick={handleTryDemo}
                whileHover={{ 
                  scale: 1.05,
                  transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] }
                }}
              >
                {/* Demo Card */}
                <div className="card max-w-md w-full mx-auto">
                  {/* Glow Effect */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-primary/0 via-primary/0 to-primary/0 group-hover:from-primary/10 group-hover:via-primary/20 group-hover:to-primary/10 transition-smooth"></div>
                  
                  {/* Content */}
                  <div className="relative z-10">
                    {/* Video Thumbnail Placeholder */}
                    <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl mb-6 relative overflow-hidden">
                      {/* MOV Video */}
                      <video
                        autoPlay
                        muted
                        loop
                        playsInline
                        className="absolute inset-0 w-full h-full object-cover rounded-xl"
                      >
                        <source
                          src="https://res.cloudinary.com/dw2lhwcqe/video/upload/v1755530816/g8n8z7pmlqhnlngbeu7j.mp4"
                          type="video/mp4"
                        />
                        Your browser does not support the video tag.
                      </video>
                      
                      {/* Play Button Overlay */}
                      <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/10 transition-all duration-300">
                        <div className="w-16 h-16 bg-primary/80 rounded-full flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-smooth">
                          <Play className="icon-large text-white ml-1" />
                        </div>
                      </div>
                    </div>

                    {/* Demo Info */}
                    <h3 className="heading-tertiary mb-2 group-hover:text-primary transition-smooth">
                      <span className="text-highlight">AI</span> Analysis Demo
                    </h3>
                    <p className="body-small mb-4">
                      See how our <span className="text-highlight">AI</span> provides instant feedback on your basketball moves
                    </p>

                    {/* Features List */}
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center body-small">
                        <Target className="w-4 h-4 text-primary mr-2" />
                        Real-time form analysis
                      </div>
                      <div className="flex items-center body-small">
                        <TrendingUp className="w-4 h-4 text-primary mr-2" />
                        Performance improvement tips
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setIsModalOpen(false)}
            ></div>

            {/* Modal Content */}
            <motion.div
             className="relative bg-secondary rounded-2xl shadow-soft border border-gray-800 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
             transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-800">
               <h3 className="heading-tertiary"><span className="text-highlight">AI</span> Coaching Demo</h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                 className="w-8 h-8 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-smooth"
                >
                 <X className="icon-primary text-white" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6">
               <p className="body-regular mb-6">
                 Type a basketball move below and see how our <span className="text-highlight">AI</span> analyzes it:
                </p>

                {/* Input Section */}
                <div className="space-y-4">
                  <div className="relative">
                    <input
                      type="text"
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="e.g., shoot 3-pointer, dribble, layup, defense..."
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-smooth font-body"
                    />
                  </div>

                  <button
                    onClick={handleAnalyzeMove}
                    disabled={!userInput.trim() || isAnalyzing}
                    className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                  >
                    {isAnalyzing ? (
                      <span className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Analyzing...
                      </span>
                    ) : (
                      'Analyze Move'
                    )}
                  </button>
                </div>

                {/* AI Response */}
                {aiResponse && (
                  <motion.div
                    className="mt-6 p-4 bg-gray-800/50 rounded-xl border border-primary/20"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                        <Zap className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="text-primary font-semibold mb-2 font-body"><span className="text-highlight">AI</span> Coach Analysis:</h4>
                        <p className="body-regular">{aiResponse}</p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Example Prompts */}
                <div className="mt-6">
                  <p className="body-small mb-3">Try these examples:</p>
                  <div className="flex flex-wrap gap-2">
                    {Object.keys(aiResponses).slice(0, 4).map((example) => (
                      <button
                        key={example}
                        onClick={() => setUserInput(example)}
                        className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-gray-300 body-small rounded-full transition-smooth font-body"
                      >
                        {example}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default InteractiveTeaserSection;